export function Title() {
    return <>
        <div><h1 className="title">CONCEPT CORE</h1></div>
    </>
}