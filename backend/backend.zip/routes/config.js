const JWT_SECRET = "aval";
export default JWT_SECRET;